from pymongo import MongoClient
from bson.objectid import ObjectId
from flask_api import FlaskAPI
from bson.json_util import dumps
from bson import json_util
from flask import jsonify
import os
import json

app = FlaskAPI(__name__)

client = MongoClient('mongodb://127.0.0.1:27017/')
database = client.xplurdb


class Products():

    def create_products(data):
        data['_id'] = str(ObjectId())
        result = database.products.insert_one(data)
        return result.inserted_id

    def update_products(prod_id, data):
        result = database.products.update_one(
            {"_id": prod_id},
            {
                "$set": data
            })
        print(result.raw_result['updatedExisting'])
        return result.raw_result['updatedExisting']

    def get_products():
        result = database.products.find()
        list_cur = list(result)
        json_data = dumps(list_cur)
        json_object = json.loads(json_data)
        json_formatted_str = json.dumps(json_object, indent=2)
        return json_data

    def get_product(id):
        result = database.products.find({"_id": ObjectId(id)})
        list_cur = list(result)
        json_data = dumps(list_cur)
        json_object = json.loads(json_data)
        json_formatted_str = json.dumps(json_object, indent=2)
        return json_formatted_str

    def delete_products(id):
        result = database.products.delete_one({'_id': ObjectId(id)})
        # Default return value is True. Check the result and return the value as success/failure
        return True