from flask import request, url_for
from flask_api import FlaskAPI, status, exceptions
from products import Products
from flask import jsonify
import json
import jwt

app = FlaskAPI(__name__)
# app.config['SECRET_KEY'] = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJPbmxpbmUgSldUIEJ1aWxkZXIiLCJpYXQiOjE2MzAxNDg1NzksImV4cCI6MTY2MTY4NDU3OSwiYXVkIjoid3d3LmV4YW1wbGUuY29tIiwic3ViIjoianJvY2tldEBleGFtcGxlLmNvbSIsIkdpdmVuTmFtZSI6IkpvaG5ueSIsIlN1cm5hbWUiOiJSb2NrZXQiLCJFbWFpbCI6Impyb2NrZXRAZXhhbXBsZS5jb20iLCJSb2xlIjpbIk1hbmFnZXIiLCJQcm9qZWN0IEFkbWluaXN0cmF0b3IiXX0.DqsM4dToOwzI70x1MFZM3r1ZBr2VWOL-78Y5XmYcpkQ'


def token_required(f):
    # @wraps(f)
    def decorated(*args, **kwargs):
        print(request.headers)
        token = None
        # jwt is passed in the request header
        pvt_token = jwt.encode({"some": "payload"}, app.config['SECRET_KEY'], algorithm="RS256")
        if 'Authorization' in request.headers:
            token = request.headers['Authorization']
        # if 'x-access-token' in request.headers:
        #     token = request.headers['x-access-token']
        # return 401 if token is not passed
        if not token:
            return jsonify({'message': 'Token is missing !!'}), 401

        try:
            # decoding the payload to fetch the stored details
            data = jwt.decode(token, app.config['SECRET_KEY'])
            if data:
                return True
            else:
                return False
        except:
            return jsonify({
                'message': 'Token is invalid !!'
            }), 401
        # returns the current logged in users contex to the routes
        return f(*args, **kwargs)

    return decorated


@app.route("/", methods=['GET', 'POST'])
def start_products():
    data = 'Products CRUD Operation through Api calls.'
    return data


@app.route("/product/add", methods=['POST'])
# @token_required
def create_products():
    req_data = request.data
    data = {}
    if 'name' in req_data and req_data['name'] != '':
        data['name'] = req_data['name']
    else:
        return {'success': False, 'result': 'Name Field is missing.'}

    if 'description' in req_data:
        data['description'] = req_data['description'] #Description is not mandatory

    if 'sku' in req_data and req_data['sku'] != '':
        data['sku'] = req_data['sku']
    else:
        return {'success': False, 'result': 'SKU is missing.'}

    if 'category' in req_data and req_data['category'] != '':
        data['category'] = req_data['category']
    else:
        return {'success': False, 'result': 'Category is missing.'}

    if 'price' in req_data and req_data['price'] != '':
        data['price'] = req_data['price']
    else:
        return {'success': False, 'result': 'Price is missing.'}

    print(data)
    id = Products.create_products(data)
    return {'success': True, 'result': 'Created Successfully. Unique Id:'+id}


@app.route("/product/update", methods=['PUT'])
def update_product():
    req_data = request.data
    data = {}
    if 'name' in req_data:
        data['name'] = req_data['name']
    if 'description' in req_data:
        data['description'] = req_data['description']
    if 'sku' in req_data:
        data['sku'] = req_data['sku']
    if 'category' in req_data:
        data['category'] = req_data['category']
    if 'price' in req_data:
        data['price'] = req_data['price']

    if 'id' in req_data and req_data['id'] != '':
        id = req_data['id']
    else:
        return {'success': False, 'result': 'Mandatory Field is missing.'}

    res = Products.update_products(id, data)
    if res:
        return {'success': True, 'result': 'Updated Successfully'}
    else:
        return {'success': False, 'result': 'Failed to update the data. Please try again later.'}


@app.route("/product", methods=['GET'])
# @token_required
def get_products():
    res = Products.get_products()
    return {'success': True, 'result': res}


@app.route("/product/<id>", methods=['GET'])
def get_one_product(id):
    if id == '':
        return {'success': True, 'result': 'Mandatory Field is missing.'}
    res = Products.get_product(id)
    return {'success': True, 'result': res}


@app.route("/product/delete/<id>", methods=['DELETE'])
def delete_product(id):
    if id == '':
        return {'success': True, 'result': 'Mandatory Field is missing.'}
    res = Products.delete_products(id)
    if res:
        return {'success': True, 'result': 'Deleted Successfully'}
    else:
        return {'success': True, 'result': 'Failed to delete the data. Please try again later.'}


if __name__ == "__main__":
    app.run(debug=True)